using System;
using UstaPlatform.Domain.Entities;
using UstaPlatform.Domain.Interfaces;

namespace UstaPlatform.Plugins.HaftaSonuEk
{
    public class HaftaSonuEkUcreti : IPricingRule
    {
        public string Name => "HaftaSonuEkUcreti";

        public decimal Apply(decimal currentPrice, WorkOrder workOrder)
        {
            var dow = workOrder.Baslangic.DayOfWeek;
            if (dow == DayOfWeek.Saturday || dow == DayOfWeek.Sunday)
                return currentPrice + 50m;
            return currentPrice;
        }
    }
}
