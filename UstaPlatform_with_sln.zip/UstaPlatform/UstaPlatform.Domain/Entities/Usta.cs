using System;

namespace UstaPlatform.Domain.Entities
{
    public class Usta
    {
        public Guid Id { get; init; } = Guid.NewGuid();
        public string Isim { get; init; } = string.Empty;
        public string Uzmanlik { get; init; } = string.Empty;
        public double Puan { get; set; }
        public int AktifIsSayisi { get; set; }
    }
}
