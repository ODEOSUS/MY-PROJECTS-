using System;

namespace UstaPlatform.Domain.Entities
{
    public class Vatandas
    {
        public Guid Id { get; init; } = Guid.NewGuid();
        public string Isim { get; init; } = string.Empty;
        public string Adres { get; init; } = string.Empty;
    }
}
