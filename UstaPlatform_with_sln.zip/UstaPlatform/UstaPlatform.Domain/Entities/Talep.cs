using System;

namespace UstaPlatform.Domain.Entities
{
    public class Talep
    {
        public Guid Id { get; init; } = Guid.NewGuid();
        public string Aciklama { get; init; } = string.Empty;
        public DateTime IstenenZaman { get; init; } = DateTime.Now;
        public string TalepTuru { get; init; } = string.Empty;
    }
}
