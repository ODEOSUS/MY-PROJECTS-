using System;

namespace UstaPlatform.Domain.Entities
{
    public class WorkOrder
    {
        public Guid Id { get; init; } = Guid.NewGuid();
        public Talep Talep { get; init; } = new Talep();
        public Usta? AtananUsta { get; init; }
        public decimal Fiyat { get; set; }
        public DateTime Baslangic { get; set; } = DateTime.Now;
    }
}
