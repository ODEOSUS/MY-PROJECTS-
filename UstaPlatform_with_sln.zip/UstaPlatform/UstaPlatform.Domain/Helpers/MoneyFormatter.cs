namespace UstaPlatform.Domain.Helpers
{
    public static class MoneyFormatter
    {
        public static string Format(decimal value) => string.Format("{0:C}", value);
    }
}
