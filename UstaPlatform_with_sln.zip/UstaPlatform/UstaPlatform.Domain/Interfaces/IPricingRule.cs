using System;
using UstaPlatform.Domain.Entities;

namespace UstaPlatform.Domain.Interfaces
{
    public interface IPricingRule
    {
        string Name { get; }
        decimal Apply(decimal currentPrice, WorkOrder workOrder);
    }
}
