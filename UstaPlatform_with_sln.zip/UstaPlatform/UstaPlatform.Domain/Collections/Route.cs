using System.Collections;
using System.Collections.Generic;

namespace UstaPlatform.Domain.Collections
{
    public class Route : IEnumerable<(int X,int Y)>
    {
        private readonly List<(int X,int Y)> _stops = new();
        public void Add(int X, int Y) => _stops.Add((X,Y));
        public IEnumerator<(int X,int Y)> GetEnumerator() => _stops.GetEnumerator();
        IEnumerator IEnumerable.GetEnumerator() => GetEnumerator();
    }
}
