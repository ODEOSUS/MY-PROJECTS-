using System;
using System.Collections.Generic;

namespace UstaPlatform.Domain.Collections
{
    public class Schedule
    {
        private readonly Dictionary<DateOnly, List<object>> _byDay = new();
        public List<object> this[DateOnly day]
        {
            get
            {
                if (!_byDay.TryGetValue(day, out var list))
                {
                    list = new List<object>();
                    _byDay[day] = list;
                }
                return list;
            }
        }
    }
}
