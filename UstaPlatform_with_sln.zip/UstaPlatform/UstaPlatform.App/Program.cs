using System;
using System.IO;
using Microsoft.Extensions.DependencyInjection;
using UstaPlatform.Domain.Entities;
using UstaPlatform.Infrastructure.Repositories;
using UstaPlatform.Pricing;

namespace UstaPlatform.App
{
    class Program
    {
        static void Main(string[] args)
        {
            var services = new ServiceCollection();
            services.AddSingleton<PricingEngine>();
            services.AddSingleton<UstaRepository>();
            var sp = services.BuildServiceProvider();

            var engine = sp.GetRequiredService<PricingEngine>();

            // plugins klasörü (uygulama bin içinde plugins olacak şekilde)
            var pluginsFolder = Path.Combine(AppContext.BaseDirectory, "plugins");
            Console.WriteLine($"Plugin klasörü: {pluginsFolder}");
            engine.LoadRulesFromFolder(pluginsFolder);

            var repo = sp.GetRequiredService<UstaRepository>();
            repo.Add(new Usta { Isim = "Ali", Uzmanlik = "tesisat", Puan = 4.5, AktifIsSayisi = 1 });
            repo.Add(new Usta { Isim = "Veli", Uzmanlik = "tesisat", Puan = 4.2, AktifIsSayisi = 0 });
            repo.Add(new Usta { Isim = "Fatmagul", Uzmanlik = "elektrik", Puan = 4.8, AktifIsSayisi = 2 });

            var talep = new Talep { Aciklama = "Musluk sızıntısı", IstenenZaman = DateTime.Now.AddHours(2), TalepTuru = "tesisat" };
            var usta = repo.GetLeastBusy(talep.TalepTuru);
            if (usta == null)
            {
                Console.WriteLine("Uygun usta bulunamadı.");
                return;
            }

            var wo = new WorkOrder { Talep = talep, AtananUsta = usta, Baslangic = talep.IstenenZaman };
            var basePrice = 200m;
            wo.Fiyat = engine.CalculatePrice(basePrice, wo);

            Console.WriteLine("--- Demo Çıktısı ---");
            Console.WriteLine($"Talep: {talep.Aciklama}");
            Console.WriteLine($"Atanan Usta: {usta.Isim} (Uzmanlık: {usta.Uzmanlik})");
            Console.WriteLine($"Fiyat: {wo.Fiyat:C}");
            Console.WriteLine("Yüklü kurallar:");
            foreach (var r in engine.Rules)
            {
                Console.WriteLine($" - {r.Name}");
            }
            Console.WriteLine("(Plugin yoksa sadece base fiyat gösterilir.)");
        }
    }
}
