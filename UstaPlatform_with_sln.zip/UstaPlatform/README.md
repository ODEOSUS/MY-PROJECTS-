# UstaPlatform - Ödev Projesi (Skeleton)

Bu arşiv Visual Studio veya `dotnet` ile açıp derleyebileceğiniz bir proje iskeletidir.
Amaç: Ödev rehberindeki yapı ve gereksinimleri sağlayan minimal, çalıştırılabilir bir örnek.

## İçerik
- UstaPlatform.Domain (class lib) - domain modelleri ve arayüzler
- UstaPlatform.Pricing (class lib) - PricingEngine ve plugin loader
- UstaPlatform.Infrastructure (class lib) - basit repository
- UstaPlatform.App (console) - demo uygulama (Program.cs)
- UstaPlatform.Plugins.HaftaSonuEk (class lib) - örnek plugin (kaynak)
- UstaPlatform.Tests (xUnit) - örnek testler (kaynak)
- README.md - bu dosya

## Açma ve Derleme
1. Bilgisayarınızda .NET SDK (7.0 veya 8.0 önerilir) ve Visual Studio yüklü olmalı.
2. Visual Studio ile klasörü açın (`File -> Open -> Folder`) veya terminalde:
   - `dotnet restore`
   - `dotnet build`
   - `dotnet run --project UstaPlatform.App/UstaPlatform.App.csproj`
3. Plugin DLL'lerini kullanmak için `UstaPlatform.Plugins.HaftaSonuEk` projesini build edin ve `UstaPlatform.App/bin/Debug/net8.0/plugins/` klasörüne kopyalayın.
   (Visual Studio ile build yapınca DLL doğrudan `bin` içinde oluşacaktır.)

## Notlar
- Bu paket **hazır derlenmiş DLL** içermez; Visual Studio'da projeleri derleyip çalıştırmanız gerekiyor.
- Eğer isterseniz ben bu dosyaları daha fazla genişletip (ör. tests, daha çok plugin örneği) ekleyebilirim.
