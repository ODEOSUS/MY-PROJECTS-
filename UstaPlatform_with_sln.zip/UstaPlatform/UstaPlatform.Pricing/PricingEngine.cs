using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Runtime.Loader;
using UstaPlatform.Domain.Entities;
using UstaPlatform.Domain.Interfaces;

namespace UstaPlatform.Pricing
{
    public class PricingEngine
    {
        private readonly List<IPricingRule> _rules = new();

        public IReadOnlyList<IPricingRule> Rules => _rules.AsReadOnly();

        public void LoadRulesFromFolder(string folderPath)
        {
            if (!Directory.Exists(folderPath)) Directory.CreateDirectory(folderPath);

            foreach (var file in Directory.EnumerateFiles(folderPath, "*.dll"))
            {
                try
                {
                    // Basit bir yükleme; production için daha dikkatli olunmalıdır.
                    var alc = new AssemblyLoadContext(file, true);
                    using var stream = File.OpenRead(file);
                    var asm = alc.LoadFromStream(stream);
                    var types = asm.GetTypes().Where(t => typeof(IPricingRule).IsAssignableFrom(t) && !t.IsInterface && !t.IsAbstract);
                    foreach (var t in types)
                    {
                        if (Activator.CreateInstance(t) is IPricingRule rule)
                        {
                            _rules.Add(rule);
                        }
                    }
                }
                catch
                {
                    // Hata durumunda atla (log eklenebilir)
                }
            }
        }

        public decimal CalculatePrice(decimal basePrice, WorkOrder wo)
        {
            var price = basePrice;
            foreach (var r in _rules) price = r.Apply(price, wo);
            return price;
        }
    }
}
