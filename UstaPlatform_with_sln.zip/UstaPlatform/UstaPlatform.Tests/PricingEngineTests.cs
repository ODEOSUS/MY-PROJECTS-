using System;
using System.IO;
using UstaPlatform.Domain.Entities;
using UstaPlatform.Pricing;
using Xunit;

namespace UstaPlatform.Tests
{
    public class PricingEngineTests
    {
        [Fact]
        public void CalculatePrice_WithNoRules_ReturnsBasePrice()
        {
            var engine = new PricingEngine();
            var wo = new WorkOrder { Baslangic = DateTime.Now };
            var price = engine.CalculatePrice(100m, wo);
            Assert.Equal(100m, price);
        }

        // Not a full integration test - plugin loading requires built DLLs.
    }
}
