using System.Collections.Generic;
using System.Linq;
using UstaPlatform.Domain.Entities;

namespace UstaPlatform.Infrastructure.Repositories
{
    public class UstaRepository
    {
        private readonly List<Usta> _ustalar = new();

        public IEnumerable<Usta> GetAll() => _ustalar.AsReadOnly();

        public void Add(Usta u) => _ustalar.Add(u);

        public Usta? GetLeastBusy(string uzmanlik) =>
            _ustalar.Where(u => u.Uzmanlik == uzmanlik).OrderBy(u => u.AktifIsSayisi).FirstOrDefault();
    }
}
